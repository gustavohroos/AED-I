# Trabalho-Agenda
Name: Gustavo Henrique Roos & Allan Nornberg Schuch;<br>
Registration: 20101184 & 20100470;<br>
Email: ghroos@inf.ufpel.edu.br & anschuch@inf.ufpel.edu.br;<br>
Performed activities: "Trabalho: Agenda" from AED-I;<br>
agenda.c is the source code;<br>
entrada.txt is the entries used in valgrind.txt;<br>
valgrind.txt is the report of the program agenda.c with the entries entrada.txt.<br>
##
To compile and run the source code, just type $ gcc agenda.c -o agenda && valgrind ./agenda < entrada.txt<br>